package br.edu.ifrs.restinga.ds1.spring.sistemagerenciamentotarefas.dao;

import br.edu.ifrs.restinga.ds1.spring.sistemagerenciamentotarefas.model.Tarefa;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TarefaDAO extends CrudRepository<Tarefa, Integer> {
    
    Iterable<Tarefa> findBySummary(String summary); 
    
    Iterable<Tarefa> findBySummaryContaining(String summary);

}