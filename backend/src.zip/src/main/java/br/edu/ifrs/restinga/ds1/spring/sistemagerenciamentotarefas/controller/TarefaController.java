package br.edu.ifrs.restinga.ds1.spring.sistemagerenciamentotarefas.controller;

import br.edu.ifrs.restinga.ds1.spring.sistemagerenciamentotarefas.dao.TarefaDAO;
import br.edu.ifrs.restinga.ds1.spring.sistemagerenciamentotarefas.errors.NaoEncontrado;
import br.edu.ifrs.restinga.ds1.spring.sistemagerenciamentotarefas.errors.RequisicaoInvalida;
import br.edu.ifrs.restinga.ds1.spring.sistemagerenciamentotarefas.model.Tarefa;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class TarefaController {
    
    @Autowired
    TarefaDAO tarefaDAO;
    
    
    @RequestMapping (path= "/tarefas", method = RequestMethod.GET)
    public Iterable <Tarefa> listarTarefas() {
        return  tarefaDAO.findAll();
    }
 
    @RequestMapping(path = "/tarefas/pesquisar/summary", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public Iterable<Tarefa> pesquisarLivro(
            @RequestParam(required = false) String igual,
            @RequestParam(required = false) String contem) {
        if (igual != null && !igual.isEmpty()) {
            return tarefaDAO.findBySummary(igual);
        } else {
            return tarefaDAO.findBySummaryContaining(contem);

        }
    }

    @RequestMapping( path = "/tarefas" , method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    public Tarefa insertTarefa (@RequestBody Tarefa tarefa) {
        tarefa.setId(0);
        
        if (tarefa.getSummary()== null || tarefa.getSummary().isEmpty()) {
            throw new RequisicaoInvalida("Preencher o summary da tarefa");
        }
        if (tarefa.getDescription() == null || tarefa.getDescription().isEmpty()){
            throw new RequisicaoInvalida("Preencha o description da tarefa");
        }
        Tarefa tarefaSave = tarefaDAO.save(tarefa);
        return tarefaSave;
    }
    
    @RequestMapping(path = "/tarefas/{id}", method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Tarefa atualizar(@PathVariable int id, @RequestBody Tarefa tarefa) {
        if (tarefa.getSummary()== null || tarefa.getSummary().isEmpty()) {
            throw new RequisicaoInvalida("Preencher o summary da tarefa");
        }
        
        Optional<Tarefa> optionalTarefaBanco = tarefaDAO.findById(id);
        if(!optionalTarefaBanco.isPresent())
            throw new NaoEncontrado("ID não encontrada");
        Tarefa tarefaBanco = optionalTarefaBanco.get();
        tarefaBanco.setSummary(tarefa.getSummary());
        tarefaBanco.setDescription(tarefa.getDescription());
        tarefaBanco.setStoryPoints(tarefa.getStoryPoints());
        
        
        Tarefa tarefaSave = tarefaDAO.save(tarefa);
        return tarefaSave;
    }

    @RequestMapping(path = "/tarefas/{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void apagar(@PathVariable int id) {

        if (!tarefaDAO.existsById(id)) {
            throw new NaoEncontrado("ID não encontrada");
        }
        
        tarefaDAO.deleteById(id);
    }   
}
