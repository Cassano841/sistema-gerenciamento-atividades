package br.edu.ifrs.restinga.ds1.spring.sistemagerenciamentotarefas.dao;

import br.edu.ifrs.restinga.ds1.spring.sistemagerenciamentotarefas.model.Usuario;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

public interface UsuarioDAO {
   /* @Repository
    public interface UsuarioDAO extends CrudRepository<Usuario, Integer> {
    */
    }
