import React, { Component } from 'react';
import BarraNavegacao from './components/Begin/BarraNavegacao';
import './App.css';


class App extends Component {
  render () {
    return (
      <div className="container">
        <BarraNavegacao />
        {this.props.children}
      </div>
    );
  }
}

export default App;
