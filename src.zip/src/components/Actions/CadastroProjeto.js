import React, { Component } from "react";

export default class CadastroAtividade extends Component {
  constructor() {
    super();
    // inicializa os campos
    this.state = {
      summary: "",
      description: "",
      finalDate: ""
    };
  }
  // função genérica para atribuir valores do estado
  setValor(campo, valor) {
    this.setState(estadoAntigo => {
      estadoAntigo[campo] = valor;
      return estadoAntigo;
    });
  }

  // função que notifica o componente pai
  // através da callback cadastrar
  enviar() {
    let cadastro = {
      summary: this.state.summary,
      description: this.state.description,
      storyPoints: this.state.storyPoints,
      finalDate: this.state.finalDate
    };

    this.props.cadastrar(cadastro);
  }

  render() {
    return (
      <form
        onSubmit={evento => {
          // Previne que o formulário faça o submit
          // trata o envio pelo método enviar
          evento.preventDefault();
          this.enviar();
        }}
        style={{
          border: "1px solid black",
          padding: "10px"
        }}
      >
        <label>Summary: </label>
        <input
          type="text"
          value={this.state.summary}
          required
          onChange={evento => this.setValor("summary", evento.target.value)}
        />
        <br />
        <br />

        <label>Description:</label>
        <input
          type="text"
          value={this.state.cpf}
          required
          onChange={evento => this.setValor("description", evento.target.value)}
        />
        <br />
        <br />

        <label>Data Entrega:</label>
        <input
          type="date"
          value={this.state.finalDate}
          onChange={evento => this.setValor("finalDate", evento.target.value)}
        />
        <br />
        <br />

        <button type="submit">Criar</button>
      </form>
    );
  }
}
