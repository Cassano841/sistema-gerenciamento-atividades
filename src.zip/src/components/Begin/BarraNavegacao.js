import React, { Component } from 'react';
//import { Link, hashHistory } from 'react-router';
import { Grid, Col, Row, Nav, Navbar, NavItem, MenuItem, NavDropdown, Button, Tabs, Tab, ButtonToolbar} from 'react-bootstrap'

export default class Login extends Component {

    botaoLogOut = {
        title : 'Sign in', 
       // actionLogin : () => hashHistory.push('Login')
    }

    render() {
        return (
          <div className="App">
            <Navbar>
                <Navbar.Header>
                    <Navbar.Brand>
                    <a href="#home">Fast Fox</a>
                    </Navbar.Brand>
                </Navbar.Header>

                <Nav>
                    <NavItem eventKey={1} href="#">
                    Projetos
                    </NavItem>
                    <NavItem eventKey={2} href="#">
                    Perfil
                    </NavItem>
                    <NavDropdown eventKey={3} title="Criar..." id="basic-nav-dropdown">
                    <MenuItem eventKey={3.1}>Action</MenuItem>
                    <MenuItem eventKey={3.2}>Another action</MenuItem>
                    <MenuItem eventKey={3.3}>Something else here</MenuItem>
                    <MenuItem divider />
                    <MenuItem eventKey={3.4}>Separated link</MenuItem>
                    </NavDropdown>
                </Nav>
            </Navbar>;
    
            <Grid>
                <Row className="show-grid">
                    <Col lg={8}>
                        <Tabs defaultActiveKey={1} id="uncontrolled-tab-example">
                            <Tab eventKey={1} title="Issues">
                                <ButtonToolbar>
                                <p></p>
                                {/* Standard button */}
                                <Button>Ver Todas as issues</Button>
                                
                                {/* Indicates a successful or positive action */}
                                <Button bsStyle="success">Criar uma história</Button>
                                
                                {/* Indicates a dangerous or potentially negative action */}
                                <Button bsStyle="danger">Criar um bug</Button>
                                </ButtonToolbar>;
                            </Tab>

                            <Tab eventKey={2} title="Notícias">
                                Tab 2 content
                            </Tab>
                            <Tab eventKey={3} title="Help">
                                Oi
                            </Tab>
                        </Tabs>
                    </Col>
                </Row>
            </Grid>
          </div>
        );
      }
}